# Resurrect save dir

By default Tmux environment is saved to a file in `~/.tmux/resurrect` dir.
Change this with:

    set -g @resurrect-dir '/some/path'
